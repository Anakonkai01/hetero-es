"""The live lab as a notebook sees it: one signed-in session, experiments, device switches and polled frames.

The session comes from `scripts/lab-login.py` (~/.config/heteroes-demo/session.json, 0600); no secret is ever written by
this module or printed into a notebook.
"""

import json
import os
from pathlib import Path
import time

from heteroes.demo.state import build_frame
from heteroes.v3.lab_cli import Lab, offer_experiment

SESSION = Path.home() / ".config" / "heteroes-demo" / "session.json"
TOKEN_ENV = "HETEROES_DEMO_ACCESS_TOKEN"
TERMINAL = ("COMPLETED", "FAILED", "CANCELLED")
COORDINATOR_RUNS = Path.home() / ".local" / "share" / "heteroes-worker" / "agent-state" / "runs"


def coordinator_events(run_id, root=COORDINATOR_RUNS):
    """The coordinator's own event log when it runs on this machine (audits, validation), shaped like lab events."""
    path = Path(root) / run_id / "events.jsonl"
    if not path.exists():
        return lambda: []

    def read():
        out = []
        for line in path.read_text(encoding="utf-8").splitlines():
            try:
                event = json.loads(line)
            except ValueError:
                continue  # a line being written
            if event.get("event") in (
                "audit_completed",
                "audit_mismatch",
                "validation_completed",
                "worker_joined",
                "worker_left",
            ):
                out.append({"eventType": event["event"], "workerId": event.get("worker_id"), "details": event})
        return out

    return read


class DemoLab:
    def __init__(self, session=SESSION, api=None):
        if api is None:
            value = json.loads(Path(session).read_text())
            os.environ[TOKEN_ENV] = value["token"]
            api = Lab(value["url"], value["workspace"], TOKEN_ENV)
        self.api = api

    def request(self, method, path, body=None, retries=5, sleep=time.sleep):
        """A read is retried through short network failures (the public edge resets a connection now and then)."""
        for attempt in range(retries if method == "GET" else 1):
            try:
                return self.api.request(method, path, body)
            except (OSError, RuntimeError) as error:
                # a 4xx answer is final; transport failures and 5xx from the edge are retried
                if method != "GET" or attempt == retries - 1 or str(error).startswith("Lab HTTP 4"):
                    raise
                sleep(2 * (attempt + 1))

    def devices(self):
        return self.request("GET", "/api/v1/devices")

    def device(self, worker_id):
        found = [d for d in self.devices() if d["workerId"] == worker_id]
        if not found:
            raise LookupError(f"No device of this account runs worker {worker_id}")
        return found[0]

    def set_contribution(self, worker_id, enabled):
        """The owner's ON/OFF switch for this boot; OFF makes a member of a running experiment leave it (ADR-009)."""
        d = self.device(worker_id)
        return self.request(
            "POST", f"/api/v1/devices/{d['deviceId']}/contribution", {"enabled": enabled, "bootId": d["bootId"]}
        )

    def offer(self, spec, coordinator_device_id, worker_ids, directory):
        """Upload the pinned model/data once (idempotent per directory), create the experiment and submit it."""
        experiment = offer_experiment(spec, coordinator_device_id, worker_ids, self.api, directory)
        if experiment["status"] == "DRAFT":
            experiment = self.request("POST", f"/api/v1/experiments/{experiment['experimentId']}/submit")
        return experiment

    def experiment(self, run_id):
        return self.request("GET", f"/api/v1/experiments/{run_id}")

    def timeline(self, run_id):
        return self.request("GET", f"/api/v1/experiments/{run_id}/timeline")

    def events(self, run_id):
        """This run's events of the lab feed (the newest 2,000 of all runs: enough while a run is watched)."""
        return [e for e in self.request("GET", "/api/v1/events") if e.get("experimentId") == run_id]

    def frame(self, run_id, names=None, events=None):
        """The Frame now. `events` defaults to the lab feed (slow on a busy lab: pass a cheaper source when polling)."""
        timeline = self.timeline(run_id)
        return build_frame(timeline, self.events(run_id) if events is None else events(), names), timeline

    def follow(self, run_id, names=None, every=3.0, until=None, sleep=time.sleep, events=None):
        """Yield (frame, timeline) every `every` seconds until the run ends or `until(frame)` is true."""
        while True:
            frame, timeline = self.frame(run_id, names, events)
            yield frame, timeline
            if frame.status in TERMINAL or (until is not None and until(frame)):
                return
            sleep(every)


def wait_until(check, timeout, every=5.0, clock=time.monotonic, sleep=time.sleep):
    """Call `check()` until it returns something true; that value, or TimeoutError after `timeout` seconds."""
    deadline = clock() + timeout
    while True:
        value = check()
        if value:
            return value
        if clock() >= deadline:
            raise TimeoutError(f"condition not met within {timeout} s")
        sleep(every)
