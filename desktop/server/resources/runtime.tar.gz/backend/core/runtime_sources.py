"""Exact CPU-only runtime subset shipped with the Lab Server."""

from pathlib import Path

SHARED_MODULES = (
    "__init__.py",
    "catalog.py",
    "canonical.py",
    "http_safety.py",
    "noise/__init__.py",
    "noise/contracts.py",
    "recovery_manifest.py",
    "v3/__init__.py",
    "v3/data.py",
    "v3/options.py",
    "v3/scoring.py",
    "product/__init__.py",
    "product/chunk_memory.py",
    "product/cpu_coordinator.py",
    "product/model_qualification.py",
    "product/qualification_v3.py",
    "product/energy.py",
    "product/host_detail.py",
    "product/windows_detail.py",
    "product/power.py",
    "product/telemetry.py",
    "study/__init__.py",
    "study/data.py",
    "study/models.py",
)


def shared_sources(repo):
    root = Path(repo) / "runtime/src/heteroes"
    return [(root / name, "heteroes/" + name) for name in SHARED_MODULES]


def server_sources(repo):
    repo = Path(repo)
    backend = repo / "backend"
    files = sorted({*backend.rglob("*.py"), *backend.rglob("*.sql")})
    return [
        (path, path.relative_to(repo).as_posix())
        for path in files
        if path.is_file() and not {"tests", "__pycache__"} & set(path.relative_to(backend).parts)
    ] + shared_sources(repo)
