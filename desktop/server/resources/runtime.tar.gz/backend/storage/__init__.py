"""Object storage implementations."""
